public class ARPMapping {
    
    private String mac;
    private String ipAddress;
}
