import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class HelperMethods {
    
    // public static String getInterfaceName(List<Hostname> hostnames){


    // }

    // public static String getIPAddress(){

    // }
}
